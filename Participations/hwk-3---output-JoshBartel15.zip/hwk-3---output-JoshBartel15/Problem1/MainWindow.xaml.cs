﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Problem1
{
    public partial class MainWindow : Window
    {
        private List<TVShow> TVShows = new List<TVShow>();
        private char[] chartrim = { '"', ' ' };
        public MainWindow()
        {
            InitializeComponent();

            var lines = File.ReadAllLines("TV Show Data.txt").Skip(1);

            foreach (var line in lines)
            {
                TVShows.Add(new TVShow(line));
            }
            populatelistbox(TVShows);
            populateRF();
            populateCF();
            populateLF();
        }
        private void populateLF()
        {
            foreach (var show in TVShows)
            {
                var values = show.Language.Split(',');
                foreach (var val in values)
                {
                    if (string.IsNullOrWhiteSpace(val))
                    {
                        continue;
                    }
                    string clean = val.Trim(chartrim);
                    if (!cmbLang.Items.Contains(clean))
                    {
                        cmbLang.Items.Add(clean);
                    }
                }
            }
        }

        private void populateCF()
        {
            foreach (var show in TVShows)
            {
                var values = show.Country.Split(',');
                foreach (var val in values)
                {
                    if (string.IsNullOrWhiteSpace(val))
                    {
                        continue;
                    }
                    string clean = val.Trim(chartrim);
                    if (!cmbCountry.Items.Contains(clean))
                    {
                        cmbCountry.Items.Add(clean);
                    }
                }
            }
        }

        private void populateRF()
        {
            foreach (var show in TVShows)
            {
                if (string.IsNullOrWhiteSpace(show.Rated))
                {
                    continue;
                }
                string clean = show.Rated.Trim();
                if (!cmbRating.Items.Contains(clean))
                {
                    cmbRating.Items.Add(clean);
                }
            }
        }

        private void btnFM_Click(object sender, RoutedEventArgs e)
        {
            cmbRating.SelectedIndex = 0;
            cmbCountry.SelectedIndex = 0;
            cmbLang.SelectedIndex = 0;
        }

        private void populatelistbox(List<TVShow> tVShows)
        {
            lstMovies.Items.Clear();
            foreach (var shows in TVShows)
            {
                lstMovies.Items.Add(shows);
            }

        }

        private void cmbRating_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //UpdateDataFilters();
            string rating = cmbRating.SelectedValue.ToString();
            lstMovies.Items.Clear();
            foreach (var show in TVShows)
            {
                if (show.Rated.Contains(rating))
                {
                    lstMovies.Items.Add(show);
                }
            }
        }
        private void cmbCountry_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //UpdateDataFilters();
            string rating = cmbCountry.SelectedValue.ToString();
            lstMovies.Items.Clear();
            foreach (var show in TVShows)
            {
                if (show.Country.Contains(rating))
                {
                    lstMovies.Items.Add(show);
                }
            }
        }

        private void cmbLang_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //UpdateDataFilters();
            string rating = cmbLang.SelectedValue.ToString();
            lstMovies.Items.Clear();
            foreach (var show in TVShows)
            {
                if (show.Language.Contains(rating))
                {
                    lstMovies.Items.Add(show);
                }
            }
        }
        private void lstMovies_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            TVShow selectedshow = (TVShow)lstMovies.SelectedItem;
            Poster poster = new Poster();
            poster.Setup(selectedshow);
            poster.ShowDialog();
        }
    }
}
