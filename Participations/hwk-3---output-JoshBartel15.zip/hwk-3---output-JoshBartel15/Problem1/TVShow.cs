﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    public class TVShow
    {
        public string Actors { get; set; }
        public string Awards { get; set; }
        public string Country { get; set; }
        public string Director { get; set; }
        public string Genre { get; set; }
        public string Language { get; set; }
        public string Plot { get; set; }
        public string Poster { get; set; }
        public string Rated { get; set; }
        public string Released { get; set; }
        public string Runtime { get; set; }
        public string Title { get; set; }
        public string Type { get; set; }
        public string Writer { get; set; }
        public string Year { get; set; }
        public string imdbID { get; set; }
        public string imdbRating { get; set; }
        public string imdbVotes { get; set; }
        public string totalSeasons { get; set; }

        public TVShow()
        {
            Actors = "";
            Awards = "";
            Country = "";
            Director = "";
            Genre = "";
            Language = "";
            Plot = "";
            Poster = "";
            Rated = "";
            Released = "";
            Runtime = "";
            Title = "";
            Type = "";
            Writer = "";
            Year = "";
            imdbID = "";
            imdbRating = "";
            imdbVotes = "";
            totalSeasons = "";
        }
        public TVShow(string line)
        {
            var p = line.Split('\t');

            Actors = p[1];
            Awards = p[2];
            Country = p[3];
            Director = p[4];
            Genre = p[5];
            Language = p[6];
            Plot = p[7];
            Poster = p[8];
            Rated = p[9];
            Released = p[10];
            Runtime = p[11];
            Title = p[12];
            Type = p[13];
            Writer = p[14];
            Year = p[15];
            imdbID = p[16];
            imdbRating = p[17];
            imdbVotes = p[18];
            totalSeasons = p[19];
        }

        public override string ToString()
        {
            return $"Title: {Title}, {Year}. Created in {Country} in {Language} languages. Rated {Rated}";
        }
    }
}
