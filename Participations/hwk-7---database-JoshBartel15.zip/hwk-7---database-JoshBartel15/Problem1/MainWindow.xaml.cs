﻿using Problem1.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Problem1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static DB_128040_fullaccessContext db = new DB_128040_fullaccessContext();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void ShowAllDeps()
        {
            lstData.Items.Clear();
            foreach (var item in db.Departments)
            {
                lstData.Items.Add(item);
            }
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            List<string> depname = Newtonsoft.Json.JsonConvert.DeserializeObject<List<string>>(File.ReadAllText("departments.json"));

            foreach (var item in depname)
            {
                db.Departments.Add(new Department { Name = item });
            }

            db.SaveChanges();

            ShowAllDeps();
        }
    }
}
