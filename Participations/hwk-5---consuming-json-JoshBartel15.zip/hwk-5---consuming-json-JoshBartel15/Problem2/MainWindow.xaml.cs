﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Problem2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtDog.Text) == true)
            {
                MessageBox.Show("Error", "Please input a valid dog breed", MessageBoxButton.OK,MessageBoxImage.Error);
            }

            string breeds = txtDog.Text.Trim(' ');

            if (breeds.Contains(' ') == true)
            {
                var dogInfo = breeds.Split(' ');
                string subBreed = dogInfo[0];
                string breed1 = dogInfo[1];
                breeds = $"{breed1}/{subBreed}";
            }

            string url = $"https://dog.ceo/api/breed/{breeds}/images/random";


            Breed breed = null;

            using (var client = new HttpClient())
            {
                var response = client.GetAsync(url).Result;
                if (response.IsSuccessStatusCode)
                {
                    var json = response.Content.ReadAsStringAsync().Result;
                    breed = Newtonsoft.Json.JsonConvert.DeserializeObject<Breed>(json);
                }
                else
                {
                    MessageBox.Show("Sorry there was no breed with that name");
                    txtDog.Clear();
                }
            }

            if (breed != null)
            {
                imgDog.Source = new BitmapImage(new Uri(breed.message));
            }

        }
    }
}
