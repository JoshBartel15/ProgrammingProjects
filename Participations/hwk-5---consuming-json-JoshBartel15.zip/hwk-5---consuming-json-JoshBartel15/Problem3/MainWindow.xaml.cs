﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Problem3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            btnPLPA.IsEnabled = false;
            btnStop.IsEnabled = false;
            medVid.LoadedBehavior = MediaState.Manual;
        }

        private void btnGV_Click(object sender, RoutedEventArgs e)
        {
            Video video;

            using (var client = new HttpClient())
            {
                string url = "http://pcbstuou.w27.wh-2.com/webservices/3033/api/random/video";


                var response = client.GetAsync(url).Result;

                if (response.IsSuccessStatusCode)
                {
                    video = Newtonsoft.Json.JsonConvert.DeserializeObject<Video>(response.Content.ReadAsStringAsync().Result);
                    medVid.Source = new Uri(video.url);
                    btnPLPA.Content = "Pause";
                    btnPLPA.IsEnabled = true;
                }
            }
        }

        private void btnPLPA_Click(object sender, RoutedEventArgs e)
        {
            string status = btnPLPA.Content.ToString().ToLower();

            switch(status)
            {
                case "play":
                    medVid.Play();
                    btnPLPA.Content = "Pause";
                    break;
                case "pause":
                    medVid.Pause();
                    btnPLPA.Content = "Play";
                    break;
                default:
                    break;
            }
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            medVid.Stop();
        }
    }
}
