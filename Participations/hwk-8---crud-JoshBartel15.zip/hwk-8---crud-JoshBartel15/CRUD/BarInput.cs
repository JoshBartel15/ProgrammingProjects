﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CRUD
{
    public class BarInput
    {
        public int bar_id { get; set; }

        public string bar_name { get; set; }

        public string location { get; set; }

        public override string ToString()
        {
            return $"{bar_name} - {location}";
        }
    }
}
