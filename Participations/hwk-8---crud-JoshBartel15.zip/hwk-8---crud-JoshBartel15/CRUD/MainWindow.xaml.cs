﻿using CRUD.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xaml.Schema;

namespace CRUD
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DB_128040_fullaccessContext db = new DB_128040_fullaccessContext();
        private bool ShouldLoadData = false;
        public MainWindow()
        {
            InitializeComponent();
        }
        
        private void lstStudents_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Student selectedStudent = (Student)lstStudents.SelectedItem;
            string message = "";   
            List<Bar> lb = new List<Bar>();
            List<StudentBar> lsb = new List<StudentBar>();
            
            foreach (var item in db.StudentBars)
            {
                if (item.StudentId == selectedStudent.Id)
                {
                    lsb.Add(item);
                }
            }
            foreach (var item in lsb)
            {
                foreach (var b in db.Bars)
                {
                    if (item.BarId == b.Id)
                    {
                        lb.Add(b);
                    }
                }
            }
            foreach (var item in lb)
            { 

                        message += $"Bar Name: {item.Name} Location: {item.Location}\n";
            }
        
            MessageBox.Show(message);
        
        }
        
        private void lstBars_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Bar selectedBar = (Bar)lstBars.SelectedItem;
            //make a messagebox that displays what students have visited the bar by matching though the studentbar table
            string message = "";
            List<Student> ls = new List<Student>();
            List<StudentBar> lsb = new List<StudentBar>();
            foreach (var item in db.StudentBars)
            {
                if (item.BarId == selectedBar.Id)
                {
                    lsb.Add(item);
                }
            }
            foreach (var item in lsb)
            {
                foreach (var s in db.Students)
                {
                    if (item.StudentId == s.Id)
                    {
                        ls.Add(s);
                    }
                }
            }
            foreach (var item in ls)
            {
                message += $"{item.FirstName} {item.LastName}\n";
            }
            MessageBox.Show(message);
        }

        private void btnUpload_Click(object sender, RoutedEventArgs e)
        {
            DeletedDB();
            BarDB();
            foreach (var item in db.Bars)
           {
               lstBars.Items.Add(item);
           }
           foreach (var item in db.Students)
           {
               lstStudents.Items.Add(item);
           }
        }


        private void DeletedDB()
        {
            foreach (var item in db.StudentBars)
            {
                db.StudentBars.Remove(item);
            }
            foreach (var item in db.Students)
            {
                db.Students.Remove(item);
            }
            foreach (var item in db.Bars)
            {
                db.Bars.Remove(item);
            }
            db.SaveChanges();
        }

        private void BarDB()
        {
            //if (load == false) return;
            List<Bar> bars = new List<Bar>();
            List<Student> students = new List<Student>();
            List<StudentBar> studentBars = new List<StudentBar>();

            List<BarInput> barjson = JsonConvert.DeserializeObject<List<BarInput>>(File.ReadAllText("bars.json"));
            List<StudentInput> studentjson = JsonConvert.DeserializeObject<List<StudentInput>>(File.ReadAllText("students.json"));
            foreach (var item in barjson)
            {
                Bar br = new Bar(item);
                db.Bars.Add(br);
                bars.Add(br);
            }
            db.SaveChanges();

            foreach (var item in studentjson)
            {
                Student student = new Student(item);
                db.Students.Add(student);
                db.SaveChanges();
                foreach (int b in item.bar_ids)
                {
                    foreach (var bar in barjson)
                    {
                        if (b == bar.bar_id)
                        { foreach(var sb in db.Bars)
                            {
                                if (bar.bar_name == sb.Name)
                                {
                                    db.StudentBars.Add(new StudentBar(student.Id, sb.Id));
                                }
                            }
                        }
                    }
                }
                db.SaveChanges();
                students.Add(student);
            }

            MessageBox.Show("Data has been uploaded");
        }

        private void btnStudDelete_Click(object sender, RoutedEventArgs e)
        {
            Student selectedStudent = (Student)lstStudents.SelectedItem;
            List<StudentBar> lsb = new List<StudentBar>();
            foreach (var item in db.StudentBars)
            {
                if (item.StudentId == selectedStudent.Id)
                {
                    lsb.Add(item);
                }
            }
            foreach (var item in lsb)
            {
                db.StudentBars.Remove(item);
            }
            db.Students.Remove(selectedStudent);
            db.SaveChanges();
            lstStudents.Items.Remove(selectedStudent);
        }

        private void btnBarDelete_Click(object sender, RoutedEventArgs e)
        {
            Bar selectedBar = (Bar)lstBars.SelectedItem;
            List<StudentBar> lsb = new List<StudentBar>();
            foreach (var item in db.StudentBars)
            {
                if (item.BarId == selectedBar.Id)
                {
                    lsb.Add(item);
                }
            }   
            foreach (var item in lsb)
            {
                db.StudentBars.Remove(item);
            }
            db.Bars.Remove(selectedBar);
            db.SaveChanges();
            lstBars.Items.Remove(selectedBar);
        }
    }
}
