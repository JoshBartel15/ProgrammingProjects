﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            bool isgood = true;

            if (string.IsNullOrWhiteSpace(txtFN.Text) == true)
            {
                isgood = false;
                MessageBox.Show("Please input a valid First Name");
            }
            if (string.IsNullOrWhiteSpace(txtLN.Text) == true)
            {
                isgood = false;
                MessageBox.Show("Please input a valid Last Name");
            }
            if (string.IsNullOrWhiteSpace(txtCity.Text) == true)
            {
                isgood = false;
                MessageBox.Show("Please input a valid City");
            }
            if (string.IsNullOrWhiteSpace(txtSName.Text) == true)
            {
                isgood = false;
                MessageBox.Show("Please input a valid Street Name");
            }
            if (string.IsNullOrWhiteSpace(txtST.Text) == true)
            {
                isgood = false;
                MessageBox.Show("Please input a valid State");
            }
            double gpa;
            if (double.TryParse(txtGPA.Text, out gpa) == false)
            {
                isgood = false;
                MessageBox.Show("Please input a valid GPA");
            }
            int streetnumber, zipcode;
            if (int.TryParse(txtZC.Text, out zipcode) == false)
            {
                isgood = false;
                MessageBox.Show("Please input a valid Zip Code");
            }
            if (int.TryParse(txtSNum.Text, out streetnumber) == false)
            {
                isgood = false;
                MessageBox.Show("Please input a valid Street Number");
            }
            if(isgood == false)
            {
                return;
            }

            Student student = new Student()
            {
                FirstName = txtFN.Text,
                LastName = txtLN.Text,
                GPA = gpa,
                Major = txtMajor.Text
            };
            
            student.SetAddress(streetnumber, txtSName.Text, txtST.Text, txtCity.Text, zipcode);

            GraduationHandout.Items.Add(student);

            txtFN.Clear();
            txtLN.Clear();
            txtMajor.Clear();
            txtGPA.Clear();
            txtZC.Clear();
            txtSNum.Clear();
            txtSName.Clear();
            txtST.Clear();
            txtCity.Clear();
        }
    }
}
