﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Fulfill_Data
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private Dictionary<string, List<FulfillData>> data = new Dictionary<string, List<FulfillData>>();
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnOF_Click(object sender, RoutedEventArgs e)
        {
            string path = Environment.GetEnvironmentVariable("USERPROFILE") + @"\Downloads";

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.InitialDirectory = path;
            ofd.Filter = "Comma Seperated Value documents (.csv)|*.csv";

            if (ofd.ShowDialog() == true)
            {
                PopulateData(ofd.FileName);

                PopulateListBox("Male", lstmale);
                PopulateListBox("Female", lstfemale);
                PopulateListBox("Both", lstboth);
                PopulateListBoxGreaterThan();

                Grid.Background = Brushes.LightGreen;
            }
        }

        private void PopulateListBoxGreaterThan()
        {
            double mean = 8;
            foreach (var state in data.Keys)
            {
                foreach (var gend in data[state])
                {
                    if ("both".ToLower() == gend.gender.ToLower())
                    {
                        if (gend.mean >= mean)
                        {
                            lstmean.Items.Add(state);
                        }
                    }
                }
            }
        }

        private void PopulateListBox(string gender, ListBox lst)
        {
            double maxmean = 0;

            foreach (var item in data.Keys)
            {
                foreach (var gend in data[item])
                {
                    if (gender.ToLower() == gend.gender.ToLower())
                    {
                        if (gend.mean > maxmean)
                        {
                            maxmean = gend.mean;
                        }
                    }
                }
            }
            foreach (var state in data.Keys)
            {
                foreach (var gend in data[state])   
                {
                    if (gender.ToLower() == gend.gender.ToLower())
                    {
                        if (gend.mean == maxmean)
                        {
                            lst.Items.Add(state);
                        }
                    }
                }
            }
        }

        private void PopulateData(string file)
        {
            var lines = File.ReadAllLines(file);

            string state = "";

            for (int i = 1; i < lines.Length; i++)
            {
                var line = lines[i];
                var p = line.Split(',');
                if (string.IsNullOrWhiteSpace(p[0]) == false)
                {
                    state = p[0];
                }

                int n;
                double Mean;
                if (double.TryParse(p[3], out Mean) == false)
                {
                    continue;
                }
                if (int.TryParse(p[2], out n) == false)
                {
                    continue;
                }
                if (data.ContainsKey(state) == false)
                {
                    data.Add(state, new List<FulfillData>());
                }
                data[state].Add(new FulfillData()
                {
                    State = state,
                    gender = p[1],
                    mean = Mean,
                    N = n
                });
            }
        }
    }
}
