﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    internal class Restaurant
    {
        public string Name { get; set; }
        public string Menu { get; set; }
        public string Location { get; set; }

        public Restaurant()
        {
            Name = "";
            Menu = "";
            Location = "";
        }

        public override string ToString()
        {
            return $"{Name} main menu item: {Menu} located on {Location}";
        }
    }
}
