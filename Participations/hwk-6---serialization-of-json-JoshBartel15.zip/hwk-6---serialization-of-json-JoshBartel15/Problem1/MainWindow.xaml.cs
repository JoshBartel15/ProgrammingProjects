﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Problem1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Sales> sales = new List<Sales>();
        public MainWindow()
        {
            InitializeComponent();

            var lines = File.ReadAllLines("car_sales.csv").Skip(1);
            foreach (var line in lines)
            {
                sales.Add(new Sales(line));
            }
            PopulateList();
            Populatecmb();
        }

        private void PopulateList()
        {
            foreach (var item in sales)
            {
                lstCars.Items.Add(item);
            }
        }
        private void Populatecmb()
        {
            //add each color to the combo box if it is not already in the combo box
            cmbColors.Items.Add("All");
            cmbColors.SelectedIndex = 0;
            foreach (var item in sales)
            {
                if (!cmbColors.Items.Contains(item.Color))
                {
                    cmbColors.Items.Add(item.Color);
                }
            }
            cmbFunct.Items.Add(">=");
            cmbFunct.Items.Add("<=");
            cmbFunct.Items.Add("=");
        }

        private void btnFilter_Click(object sender, RoutedEventArgs e)
        {
            lstCars.Items.Clear();
            int year = int.Parse(txtYear.Text);
            if (cmbFunct.SelectedItem.ToString() == ">=")
            {
                foreach (var item in sales)
                {
                    if (item.Year >= year && item.Color == cmbColors.SelectedItem.ToString())
                    {
                        lstCars.Items.Add(item);
                    }
                }
            }
            else if (cmbFunct.SelectedItem.ToString() == "<=")
            {
                foreach (var item in sales)
                {
                    if (item.Year <= year && item.Color == cmbColors.SelectedItem.ToString())
                    {
                        lstCars.Items.Add(item);
                    }
                }
            }
            else if (cmbFunct.SelectedItem.ToString() == "=")
            {
                foreach (var item in sales)
                {
                    if (item.Year == year && item.Color == cmbColors.SelectedItem.ToString())
                    {
                        lstCars.Items.Add(item);
                    }
                }
            }
            lblCount.Content = "Item Count:" + lstCars.Items.Count;
        }
        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            string json = Newtonsoft.Json.JsonConvert.SerializeObject(lstCars.Items);
            File.WriteAllText("car_sales.json", json);

            MessageBox.Show("File Exported");
        }
    }
}
