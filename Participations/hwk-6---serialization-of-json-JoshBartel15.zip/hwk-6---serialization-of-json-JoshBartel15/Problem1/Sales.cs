﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    public class Sales
    {
        public string VIN{ get; set; }
        public string Make{ get; set; }
        public string Color { get; set; }
        public int Year { get; set; }
        public string Model { get; set; }
        public string SalePrice { get; set; }

        public Sales()
        {
            VIN = "";
            Make = "";
            Color = "";
            Year = 0;
            Model = "";
            SalePrice = "";
        }
        public Sales(string line)
        {
            string[] p = line.Split(',');
            VIN = p[0];
            Make = p[1];
            Color = p[2];
            Year = int.Parse(p[3]);
            Model = p[4];
            SalePrice = p[5];
        }
        public override string ToString()
        {
            return Year + " " + Make + " " + "-" + " " + Model;
        }
    }
}
