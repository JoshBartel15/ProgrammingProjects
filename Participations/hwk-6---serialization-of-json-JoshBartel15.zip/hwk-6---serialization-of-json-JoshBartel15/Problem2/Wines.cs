﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Ink;

namespace Problem2
{
    class Wines
    {
        public double id { get; set; }
        public string country { get; set; }
        public double? price { get; set; }
        public double points { get; set; }
        public string title { get; set; }
        public string variety { get; set; }
        public string winery { get; set; }
        public string description { get; set; }
        public string province { get; set; }
        public string designation { get; set; }
        public string taster_name { get; set; }
        public string taster_twitter_handle { get; set; }
        public string region_1 { get; set; }
        public string region_2 { get; set; }

        public Wines()
        {
            id = 0;
            country = "";
            price = 0;
            points = 0;
            title = "";
            variety = "";
            winery = "";
            description = "";
            province = "";
            designation = "";
            taster_name = "";
            taster_twitter_handle = "";
            region_1 = "";
            region_2 = "";
        }

        public override string ToString()
        {
            return title;
        }
    }
}
