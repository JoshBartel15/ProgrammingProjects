﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static System.Net.WebRequestMethods;

namespace Problem2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Wines> wines = new List<Wines>();
        public MainWindow()
        {
            InitializeComponent();

            string url = "http://pcbstuou.w27.wh-2.com/webservices/3033/api/Wine/Reviews";

            using (var client = new HttpClient())
            {
                string json = client.GetStringAsync(url).Result;

                wines = JsonConvert.DeserializeObject<List<Wines>>(json);
            }
            foreach (var wine in wines)
            {
                lstWines.Items.Add(wine);

                if (!cmbCountry.Items.Contains(wine.country))
                {
                    cmbCountry.Items.Add(wine.country);
                }
            }
            lblCount.Content = "Record Count:" + lstWines.Items.Count;
        }

        private void btnPrice_Click(object sender, RoutedEventArgs e)
        {
            lstWines.Items.Clear();
            string country = cmbCountry.SelectedItem.ToString();
            double? price;
            if(string.IsNullOrEmpty(txtPrice.Text) == true)
            {
                price = null;
            }
            else
            {
                price = Convert.ToDouble(txtPrice.Text);
            }
            foreach (var wine in wines)
            {
                if (wine.country == country)
                {
                    if (price == null || price >= wine.price)
                    {
                        lstWines.Items.Add(wine);
                    }
                }
            }
            lblCount.Content = "Record Count:" + lstWines.Items.Count;
        }

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            string json = JsonConvert.SerializeObject(lstWines.Items, Formatting.Indented);

            System.IO.File.WriteAllText("wines.json", json);

            MessageBox.Show("File Exported");
        }
    }
}
